SCID is the result of a partnership between the Institute for Applied Marine Ecology (IfAME) at 
        California State University Monterey Bay and the SIMoN Program at the Monterey Bay National Marine Sanctuary.
        <br />
        <span id="note">Background image courtesy IMPACT 2008</span>