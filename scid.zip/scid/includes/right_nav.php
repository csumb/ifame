<a href="index.php">View SCID</a> <p />
                <a href="about.php">About SCID</a> <p /> 
                <a href="field_ops.php">Field Ops</a> <p />
                 <a href="http://sep.csumb.edu/ifame" target="_blank"><img src="images/scid_layout/ifame_logo_link.jpg" border="0" alt="Institute for Applied Marine Ecology -  Ifame" /></a> <p />
                 <a href="http://www.sanctuarysimon.org" target="_blank"><img src="images/scid_layout/nms_logo_link.jpg" border="0" alt="National Marine Sanctuary" /></a>