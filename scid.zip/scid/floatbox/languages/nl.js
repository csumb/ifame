// Dutch
/*
fb.strings = {
"hintClose": "Sluiten (toets: Esc)",
"hintPrev": "Vorige (toets: ←)",
"hintNext": "Volgende (toets: →)",
"hintPlay": "Afspelen (toets: spatiebalk)",
"hintPause": "Pauze (toets: spatiebalk)",
"hintResize": "Grootte aanpassen (toets: Tab)",
"imgCount": "Afbeelding %1 van %2",
"nonImgCount": "Pagina %1 van %2",
"mixedCount": "(%1 van %2)",
"infoText": "Info...",
"printText": "Afdrukken...",
"flashVer": "Een nieuwere versie van 'Flash Player' is nodig om deze inhoud te bekijken.",
"needPlayer": "'%1' is nodig om deze inhoud te bekijken.",
"newWindow": "Open in een nieuw venster"
};
*/
fb.strings = {
hintClose: "Sluiten (toets: Esc)",
hintPrev: "Vorige (toets: \u2190)",
hintNext: "Volgende (toets: \u2192)",
hintPlay: "Afspelen (toets: spatiebalk)",
hintPause: "Pauze (toets: spatiebalk)",
hintResize: "Grootte aanpassen (toets: Tab)",
imgCount: "Afbeelding %1 van %2",
nonImgCount: "Pagina %1 van %2",
mixedCount: "(%1 van %2)",
infoText: "Info...",
printText: "Afdrukken...",
flashVer: "Een nieuwere versie van 'Flash Player' is nodig om deze inhoud te bekijken.",
needPlayer: "'%1' is nodig om deze inhoud te bekijken.",
newWindow: "Open in een nieuw venster"
};