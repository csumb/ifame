// Croation
/*
fb.strings = {
"hintClose": "Zatvori (tipka: Esc)",
"hintPrev": "Prethodna (tipka: ←)",
"hintNext": "Slijedeća (tipka: →)",
"hintPlay": "Pokreni (tipka: razmaknica)",
"hintPause": "Pauza (tipka: razmaknica)",
"hintResize": "Zumiraj (tipka: Tab)",
"imgCount": "Slika %1 od %2",
"nonImgCount": "Strana %1 od %2",
"mixedCount": "(%1 od %2)",
"infoText": "Info...",
"printText": "Ispiši...",
"flashVer": "Potrebna je novija verzija Flash Playera da biste vidjeli ovaj sadržaj.",
"needPlayer": "Potreban je %1 da biste vidjeli ovaj sadržaj.",
"newWindow": "Otvorite u novom prozoru"
};
*/
fb.strings = {
"hintClose": "Zatvori (tipka: Esc)",
"hintPrev": "Prethodna (tipka: \u2190)",
"hintNext": "Slijede\u0107a (tipka: \u2192)",
"hintPlay": "Pokreni (tipka: razmaknica)",
"hintPause": "Pauza (tipka: razmaknica)",
"hintResize": "Zumiraj (tipka: Tab)",
"imgCount": "Slika %1 od %2",
"nonImgCount": "Strana %1 od %2",
"mixedCount": "(%1 od %2)",
"infoText": "Info...",
"printText": "Ispi\u0161i...",
"flashVer": "Potrebna je novija verzija Flash Playera da biste vidjeli ovaj sadr\u017Eaj.",
"needPlayer": "Potreban je %1 da biste vidjeli ovaj sadr\u017Eaj.",
"newWindow": "Otvorite u novom prozoru"
};